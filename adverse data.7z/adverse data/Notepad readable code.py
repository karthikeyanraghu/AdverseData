import requests

pharm_class_epc = "tumor necrosis factor blocker"
limit  = 100

# can add parameters while scheduling the job
url = "https://api.fda.gov/drug/event.json?search=patient.drug.openfda.pharm_class_epc:\"{}\"&limit={}".format(pharm_class_epc,limit)
print(url)
response = requests.get(url)

# Check the status code to ensure the request was successful
if response.status_code == 200:
    data = response.json()
else:
    print("Failed to fetch data")


raw_data = data.get('results')
raw_data_df = spark.createDataFrame(raw_data)
raw_data_df.write.format("delta").mode("append").option("overwriteSchema", "true").option("path","/bronze_layer/adverse_events").saveAsTable("adverse_events_bz")
df2 = raw_data_df.select("*",raw_data_df["patient.patientonsetageunit"].alias("patient_patientonsetageunit"),raw_data_df["patient.patientsex"].alias("patient_patientsex"),raw_data_df["patient.reaction"].alias("patient_reaction"),raw_data_df["patient.patientonsetage"].alias("patient_patientonsetage"),raw_data_df["patient.drug"].alias("patient_drug"),raw_data_df["primarysource.qualification"].alias("qualification"))
df_final = df2.drop("patient").drop("primarysource")

# for the first run of the job
df_final.write.format("delta").mode("append").partitionBy("qualification,receivedate").option("overwriteSchema", "true").option("path","/Goldlayer/adverse_events").saveAsTable("adverse_events")

#from second run of the job
deltatable = DeltaTable.forPath(spark, '/Goldlayer/adverse_events')
deltatable.alias("target").merge(source = df_final.alias("new"),condition = "target.qualification = new.qualification and target.safetyreportid = new.safetyreportid").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

#optimzation command
%sql
spark.sql("OPTIMIZE '/Goldlayer/adverse_events' ZORDER BY (safetyreportid)")